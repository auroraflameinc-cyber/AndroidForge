# KYC Companion Project Manifest

This package contains the complete starter project generated in Work mode.

## Included Files

- `README.md`
- `.env.example`
- `docker-compose.yml`
- `Makefile`
- `backend/`
- `admin/`
- `android/`

## Build Status From Work Sandbox

| Check | Result |
| --- | --- |
| Admin `npm install` | Passed |
| Admin `npm run build` | Passed before final additions |
| Admin `npm test` | Passed before final additions |
| Backend `go test ./...` | Not run here because Go is not installed in the sandbox |
| Android Gradle tests | Not run here because Gradle/Android SDK are not installed in the sandbox |
| Docker Compose | Not run here because Docker is not installed in the sandbox |

## Safety Boundary

This project supports legitimate KYC status and verification flows only. It does not include camera injection, sensor spoofing, liveness bypass, hidden overlays, or anti-detection behavior.
