# KYC Companion

KYC Companion is a legitimate identity verification starter project with:

- Android Kotlin/Jetpack Compose app
- Safe, visible Android `TYPE_APPLICATION_OVERLAY` status widget
- Persona SDK integration points with mock mode
- Go backend with Persona webhook verification
- entgo schema definitions for PostgreSQL persistence
- SQL migration for PostgreSQL
- React/TypeScript admin UI
- Docker Compose environment
- Tests and `.env.example`

This project intentionally does **not** implement camera injection, sensor spoofing, liveness bypasses, overlay hiding, or any behavior intended to defeat security systems.

## Project Layout

```text
android/   Kotlin Android app and overlay service
backend/   Go API, Persona webhook verification, ent schemas
admin/     React/TypeScript admin dashboard
```

## What Is Implemented

| Area | Included |
| --- | --- |
| Android | Compose UI, overlay permission flow, visible status overlay, mock Persona launcher, API client |
| Backend | Inquiry creation, mock Persona mode, production Persona API client boundary, signed webhook endpoint, in-memory repository |
| Database | ent schema definitions plus SQL migration |
| Admin | Inquiry list, mock inquiry creation form, responsive dashboard |
| DevOps | Docker Compose, backend/admin Dockerfiles, Makefile, env example |

## Quick Start

Copy environment values:

```bash
cp .env.example .env
```

Start the backend and database when Docker is available:

```bash
docker compose up --build
```

Run admin UI:

```bash
cd admin
npm install
npm run dev
```

Run backend tests when Go is installed:

```bash
cd backend
go test ./...
```

Apply the SQL migration manually if you are not using ent migrations:

```bash
psql "$DATABASE_URL" -f backend/migrations/001_init.sql
```

Build Android when Android Studio or Gradle is installed:

```bash
cd android
./gradlew testDebugUnitTest
./gradlew assembleDebug
```

## Mock Mode

`PERSONA_MODE=mock` lets the Android app and admin UI test the full flow without production Persona credentials. The backend returns a mock inquiry ID and records webhook-like status updates from local calls.

## Production Persona Setup

1. Create a Persona account and template.
2. Set `PERSONA_MODE=production`.
3. Set `PERSONA_API_KEY`, `PERSONA_TEMPLATE_ID`, and `PERSONA_WEBHOOK_SECRET`.
4. Configure Persona webhook delivery to:

```text
https://your-api-domain.example.com/webhooks/persona
```

5. Keep webhook signature verification enabled.

The production Persona API client is in `backend/internal/persona/client.go`. It creates inquiries through Persona’s API using a backend-held API key. The Android app should only receive short-lived tokens or inquiry references from your backend.

## Android Overlay Safety

The overlay is a small, visible status widget. It:

- Requires user-granted overlay permission.
- Shows verification status only.
- Can be dismissed by the user.
- Does not obscure security prompts.
- Does not hide itself from screenshots, accessibility, fraud systems, or other apps.

## API

| Method | Path | Purpose |
| --- | --- | --- |
| `GET` | `/healthz` | Service health check |
| `POST` | `/api/inquiries` | Create a mock or Persona inquiry |
| `GET` | `/api/inquiries` | List inquiries for admin UI |
| `POST` | `/webhooks/persona` | Receive verified Persona events |
