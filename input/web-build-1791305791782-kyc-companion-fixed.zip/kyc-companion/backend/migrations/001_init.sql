CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS inquiries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    external_user_id TEXT NOT NULL,
    email TEXT,
    status TEXT NOT NULL DEFAULT 'created',
    provider TEXT NOT NULL DEFAULT 'persona',
    provider_mode TEXT NOT NULL DEFAULT 'mock',
    provider_inquiry_id TEXT NOT NULL UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS persona_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider_inquiry_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    status TEXT,
    received_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_inquiries_external_user_id ON inquiries (external_user_id);
CREATE INDEX IF NOT EXISTS idx_persona_events_provider_inquiry_id ON persona_events (provider_inquiry_id);
