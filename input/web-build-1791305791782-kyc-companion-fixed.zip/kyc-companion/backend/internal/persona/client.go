package persona

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"time"
)

type Client struct {
	baseURL    string
	apiKey     string
	templateID string
	httpClient *http.Client
}

type CreateInquiryInput struct {
	ExternalUserID string
	Email          string
}

type CreateInquiryResult struct {
	InquiryID   string
	ClientToken string
}

func NewClient(baseURL string, apiKey string, templateID string) Client {
	return Client{
		baseURL:    baseURL,
		apiKey:     apiKey,
		templateID: templateID,
		httpClient: &http.Client{Timeout: 15 * time.Second},
	}
}

func (c Client) CreateInquiry(ctx context.Context, input CreateInquiryInput) (CreateInquiryResult, error) {
	if c.apiKey == "" || c.templateID == "" {
		return CreateInquiryResult{}, errors.New("Persona API key and template ID are required")
	}

	payload := map[string]any{
		"data": map[string]any{
			"type": "inquiry",
			"attributes": map[string]any{
				"template-id":      c.templateID,
				"reference-id":     input.ExternalUserID,
				"account-reference": input.Email,
			},
		},
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return CreateInquiryResult{}, err
	}

	req, err := http.NewRequestWithContext(ctx, http.MethodPost, c.baseURL+"/inquiries", bytes.NewReader(body))
	if err != nil {
		return CreateInquiryResult{}, err
	}
	req.Header.Set("Authorization", "Bearer "+c.apiKey)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("Persona-Version", "2023-01-05")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return CreateInquiryResult{}, err
	}
	defer resp.Body.Close()

	if resp.StatusCode < 200 || resp.StatusCode >= 300 {
		return CreateInquiryResult{}, fmt.Errorf("Persona API returned %s", resp.Status)
	}

	var parsed struct {
		Data struct {
			ID         string `json:"id"`
			Attributes struct {
				SessionToken string `json:"session-token"`
				ClientToken  string `json:"client-token"`
			} `json:"attributes"`
		} `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&parsed); err != nil {
		return CreateInquiryResult{}, err
	}
	token := parsed.Data.Attributes.ClientToken
	if token == "" {
		token = parsed.Data.Attributes.SessionToken
	}
	return CreateInquiryResult{InquiryID: parsed.Data.ID, ClientToken: token}, nil
}
