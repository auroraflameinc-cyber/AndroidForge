package persona

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strings"
)

type WebhookEvent struct {
	EventType string
	InquiryID string
	Status    string
}

func ReadAndVerifyWebhook(r *http.Request, secret string) ([]byte, error) {
	body, err := io.ReadAll(io.LimitReader(r.Body, 1<<20))
	if err != nil {
		return nil, err
	}
	signature := r.Header.Get("Persona-Signature")
	if secret == "" {
		return nil, errors.New("webhook secret is not configured")
	}
	if !VerifySignature(body, signature, secret) {
		return nil, errors.New("invalid Persona webhook signature")
	}
	return body, nil
}

func VerifySignature(body []byte, header string, secret string) bool {
	provided := extractSignature(header)
	if provided == "" {
		return false
	}
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write(body)
	expected := hex.EncodeToString(mac.Sum(nil))
	return hmac.Equal([]byte(expected), []byte(provided))
}

func extractSignature(header string) string {
	for _, part := range strings.Split(header, ",") {
		part = strings.TrimSpace(part)
		if strings.HasPrefix(part, "v1=") {
			return strings.TrimPrefix(part, "v1=")
		}
	}
	return strings.TrimSpace(header)
}

func ParseWebhookEvent(body []byte) (WebhookEvent, error) {
	var payload struct {
		Data struct {
			Type       string `json:"type"`
			Attributes struct {
				Name   string `json:"name"`
				Status string `json:"status"`
			} `json:"attributes"`
			Relationships struct {
				Inquiry struct {
					Data struct {
						ID string `json:"id"`
					} `json:"data"`
				} `json:"inquiry"`
			} `json:"relationships"`
		} `json:"data"`
	}
	if err := json.Unmarshal(body, &payload); err != nil {
		return WebhookEvent{}, err
	}
	eventType := payload.Data.Attributes.Name
	if eventType == "" {
		eventType = payload.Data.Type
	}
	return WebhookEvent{
		EventType: eventType,
		InquiryID: payload.Data.Relationships.Inquiry.Data.ID,
		Status:    payload.Data.Attributes.Status,
	}, nil
}
