package persona

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"testing"
)

func TestVerifySignature(t *testing.T) {
	body := []byte(`{"data":{"type":"event"}}`)
	secret := "test_secret"
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write(body)
	signature := "t=123,v1=" + hex.EncodeToString(mac.Sum(nil))

	if !VerifySignature(body, signature, secret) {
		t.Fatal("expected signature to verify")
	}
	if VerifySignature(body, signature, "wrong") {
		t.Fatal("expected wrong secret to fail")
	}
}

func TestParseWebhookEvent(t *testing.T) {
	body := []byte(`{
		"data": {
			"type": "event",
			"attributes": {"name": "inquiry.completed", "status": "completed"},
			"relationships": {"inquiry": {"data": {"id": "inq_123"}}}
		}
	}`)
	event, err := ParseWebhookEvent(body)
	if err != nil {
		t.Fatal(err)
	}
	if event.EventType != "inquiry.completed" || event.InquiryID != "inq_123" || event.Status != "completed" {
		t.Fatalf("unexpected event: %#v", event)
	}
}
