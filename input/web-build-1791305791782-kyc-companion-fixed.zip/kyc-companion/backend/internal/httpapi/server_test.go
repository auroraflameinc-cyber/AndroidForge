package httpapi

import (
	"bytes"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"kyc-companion/backend/internal/config"
	"kyc-companion/backend/internal/store"
)

func TestCreateMockInquiry(t *testing.T) {
	server := NewServer(config.Config{PersonaMode: "mock"}, store.NewMemoryRepository(func() time.Time {
		return time.Unix(100, 0)
	}))
	body := bytes.NewBufferString(`{"externalUserId":"user-1","email":"user@example.com"}`)

	req := httptest.NewRequest(http.MethodPost, "/api/inquiries", body)
	rec := httptest.NewRecorder()
	server.Routes().ServeHTTP(rec, req)

	if rec.Code != http.StatusCreated {
		t.Fatalf("expected 201, got %d: %s", rec.Code, rec.Body.String())
	}
	var parsed map[string]any
	if err := json.Unmarshal(rec.Body.Bytes(), &parsed); err != nil {
		t.Fatal(err)
	}
	if parsed["providerInquiryId"] != "mock_user-1" {
		t.Fatalf("unexpected response: %#v", parsed)
	}
}
