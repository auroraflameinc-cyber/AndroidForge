package httpapi

import (
	"encoding/json"
	"net/http"

	"kyc-companion/backend/internal/config"
	"kyc-companion/backend/internal/persona"
	"kyc-companion/backend/internal/store"
)

type Server struct {
	cfg  config.Config
	repo store.Repository
}

func NewServer(cfg config.Config, repo store.Repository) Server {
	return Server{cfg: cfg, repo: repo}
}

func (s Server) Routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /healthz", s.health)
	mux.HandleFunc("POST /api/inquiries", s.createInquiry)
	mux.HandleFunc("GET /api/inquiries", s.listInquiries)
	mux.HandleFunc("POST /webhooks/persona", s.personaWebhook)
	return withCORS(mux)
}

func (s Server) health(w http.ResponseWriter, _ *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok", "mode": s.cfg.PersonaMode})
}

func (s Server) createInquiry(w http.ResponseWriter, r *http.Request) {
	var input struct {
		ExternalUserID string `json:"externalUserId"`
		Email          string `json:"email"`
	}
	if err := json.NewDecoder(r.Body).Decode(&input); err != nil {
		writeError(w, http.StatusBadRequest, "invalid JSON body")
		return
	}
	if input.ExternalUserID == "" {
		writeError(w, http.StatusBadRequest, "externalUserId is required")
		return
	}

	inquiry := store.Inquiry{
		ExternalUserID: input.ExternalUserID,
		Email:          input.Email,
		Status:         "created",
		Provider:       "persona",
		ProviderMode:   s.cfg.PersonaMode,
	}

	if s.cfg.PersonaMode == "mock" {
		inquiry.ProviderInquiryID = "mock_" + input.ExternalUserID
		inquiry.ClientToken = "mock_client_token_" + input.ExternalUserID
	} else {
		client := persona.NewClient(s.cfg.PersonaAPIBaseURL, s.cfg.PersonaAPIKey, s.cfg.PersonaTemplateID)
		result, err := client.CreateInquiry(r.Context(), persona.CreateInquiryInput{
			ExternalUserID: input.ExternalUserID,
			Email:          input.Email,
		})
		if err != nil {
			writeError(w, http.StatusBadGateway, err.Error())
			return
		}
		inquiry.ProviderInquiryID = result.InquiryID
		inquiry.ClientToken = result.ClientToken
	}

	created, err := s.repo.CreateInquiry(r.Context(), inquiry)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "could not create inquiry")
		return
	}
	writeJSON(w, http.StatusCreated, created)
}

func (s Server) listInquiries(w http.ResponseWriter, r *http.Request) {
	inquiries, err := s.repo.ListInquiries(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "could not list inquiries")
		return
	}
	writeJSON(w, http.StatusOK, inquiries)
}

func (s Server) personaWebhook(w http.ResponseWriter, r *http.Request) {
	body, err := persona.ReadAndVerifyWebhook(r, s.cfg.PersonaWebhookSecret)
	if err != nil {
		writeError(w, http.StatusUnauthorized, err.Error())
		return
	}

	event, err := persona.ParseWebhookEvent(body)
	if err != nil {
		writeError(w, http.StatusBadRequest, "invalid Persona webhook event")
		return
	}
	if err := s.repo.RecordPersonaEvent(r.Context(), event.InquiryID, event.EventType, event.Status); err != nil {
		writeError(w, http.StatusInternalServerError, "could not record Persona event")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"status": "received"})
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeError(w http.ResponseWriter, status int, message string) {
	writeJSON(w, status, map[string]string{"error": message})
}

func withCORS(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Access-Control-Allow-Origin", "*")
		w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Persona-Signature")
		w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		next.ServeHTTP(w, r)
	})
}
