package store

import (
	"context"
	"errors"
	"sync"
	"time"

	"github.com/google/uuid"
)

type Inquiry struct {
	ID                string    `json:"id"`
	ExternalUserID    string    `json:"externalUserId"`
	Email             string    `json:"email"`
	Status            string    `json:"status"`
	Provider          string    `json:"provider"`
	ProviderMode      string    `json:"providerMode"`
	ProviderInquiryID string    `json:"providerInquiryId"`
	ClientToken       string    `json:"clientToken,omitempty"`
	CreatedAt         time.Time `json:"createdAt"`
	UpdatedAt         time.Time `json:"updatedAt"`
}

type Repository interface {
	CreateInquiry(ctx context.Context, inquiry Inquiry) (Inquiry, error)
	ListInquiries(ctx context.Context) ([]Inquiry, error)
	RecordPersonaEvent(ctx context.Context, providerInquiryID string, eventType string, status string) error
}

type MemoryRepository struct {
	now       func() time.Time
	mu        sync.Mutex
	inquiries []Inquiry
}

func NewMemoryRepository(now func() time.Time) *MemoryRepository {
	return &MemoryRepository{now: now}
}

func (r *MemoryRepository) CreateInquiry(_ context.Context, inquiry Inquiry) (Inquiry, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	timestamp := r.now().UTC()
	inquiry.ID = uuid.NewString()
	inquiry.CreatedAt = timestamp
	inquiry.UpdatedAt = timestamp
	r.inquiries = append(r.inquiries, inquiry)
	return inquiry, nil
}

func (r *MemoryRepository) ListInquiries(_ context.Context) ([]Inquiry, error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	out := make([]Inquiry, len(r.inquiries))
	copy(out, r.inquiries)
	return out, nil
}

func (r *MemoryRepository) RecordPersonaEvent(_ context.Context, providerInquiryID string, _ string, status string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	for i := range r.inquiries {
		if r.inquiries[i].ProviderInquiryID == providerInquiryID {
			r.inquiries[i].Status = status
			r.inquiries[i].UpdatedAt = r.now().UTC()
			return nil
		}
	}
	return errors.New("inquiry not found")
}
