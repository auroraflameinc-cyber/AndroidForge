package config

import "os"

type Config struct {
	HTTPAddr             string
	PersonaMode          string
	PersonaAPIKey        string
	PersonaAPIBaseURL    string
	PersonaTemplateID    string
	PersonaWebhookSecret string
}

func FromEnv() Config {
	return Config{
		HTTPAddr:             env("HTTP_ADDR", ":8080"),
		PersonaMode:          env("PERSONA_MODE", "mock"),
		PersonaAPIKey:        os.Getenv("PERSONA_API_KEY"),
		PersonaAPIBaseURL:    env("PERSONA_API_BASE_URL", "https://api.withpersona.com/api/v1"),
		PersonaTemplateID:    os.Getenv("PERSONA_TEMPLATE_ID"),
		PersonaWebhookSecret: env("PERSONA_WEBHOOK_SECRET", "dev_webhook_secret_change_me"),
	}
}

func env(key string, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}
