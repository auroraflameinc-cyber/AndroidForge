package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/field"
)

type PersonaEvent struct {
	ent.Schema
}

func (PersonaEvent) Fields() []ent.Field {
	return []ent.Field{
		field.String("provider_inquiry_id"),
		field.String("event_type"),
		field.String("status").Optional(),
		field.Time("received_at").Default(time.Now),
	}
}
