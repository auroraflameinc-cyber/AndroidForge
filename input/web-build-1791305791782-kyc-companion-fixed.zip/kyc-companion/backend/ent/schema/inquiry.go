package schema

import (
	"time"

	"entgo.io/ent"
	"entgo.io/ent/schema/field"
)

type Inquiry struct {
	ent.Schema
}

func (Inquiry) Fields() []ent.Field {
	return []ent.Field{
		field.String("external_user_id"),
		field.String("email").Optional(),
		field.String("status").Default("created"),
		field.String("provider").Default("persona"),
		field.String("provider_mode").Default("mock"),
		field.String("provider_inquiry_id").Unique(),
		field.Time("created_at").Default(time.Now),
		field.Time("updated_at").Default(time.Now).UpdateDefault(time.Now),
	}
}
