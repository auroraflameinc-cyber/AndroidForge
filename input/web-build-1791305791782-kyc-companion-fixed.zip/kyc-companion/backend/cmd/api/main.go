package main

import (
	"log"
	"net/http"
	"time"

	"kyc-companion/backend/internal/config"
	"kyc-companion/backend/internal/httpapi"
	"kyc-companion/backend/internal/store"
)

func main() {
	cfg := config.FromEnv()
	repo := store.NewMemoryRepository(time.Now)
	server := httpapi.NewServer(cfg, repo)

	log.Printf("kyc-companion backend listening on %s", cfg.HTTPAddr)
	if err := http.ListenAndServe(cfg.HTTPAddr, server.Routes()); err != nil {
		log.Fatal(err)
	}
}
