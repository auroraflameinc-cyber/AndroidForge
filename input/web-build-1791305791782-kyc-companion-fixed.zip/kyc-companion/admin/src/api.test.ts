import { describe, expect, it } from 'vitest';

describe('admin API types', () => {
  it('keeps inquiry status human-readable', () => {
    const status = 'completed';
    expect(status).toMatch(/^[a-z-]+$/);
  });
});
