import { FormEvent, useEffect, useState } from 'react';
import { createInquiry, Inquiry, listInquiries } from './api';
import './styles.css';

export default function App() {
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [externalUserId, setExternalUserId] = useState('demo-user-1');
  const [email, setEmail] = useState('demo@example.com');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function refresh() {
    setLoading(true);
    setError('');
    try {
      setInquiries(await listInquiries());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load inquiries');
    } finally {
      setLoading(false);
    }
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError('');
    try {
      await createInquiry({ externalUserId, email });
      await refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create inquiry');
    }
  }

  useEffect(() => {
    void refresh();
  }, []);

  return (
    <main className="shell">
      <section className="toolbar">
        <div>
          <h1>KYC Companion Admin</h1>
          <p>Review legitimate Persona identity verification inquiries.</p>
        </div>
        <button onClick={() => void refresh()} disabled={loading}>
          {loading ? 'Refreshing' : 'Refresh'}
        </button>
      </section>

      <form className="create-form" onSubmit={(event) => void submit(event)}>
        <label>
          External user ID
          <input value={externalUserId} onChange={(event) => setExternalUserId(event.target.value)} />
        </label>
        <label>
          Email
          <input value={email} onChange={(event) => setEmail(event.target.value)} />
        </label>
        <button type="submit">Create Mock Inquiry</button>
      </form>

      {error && <p className="error">{error}</p>}

      <table>
        <thead>
          <tr>
            <th>User</th>
            <th>Email</th>
            <th>Status</th>
            <th>Mode</th>
            <th>Persona Inquiry</th>
          </tr>
        </thead>
        <tbody>
          {inquiries.map((inquiry) => (
            <tr key={inquiry.id}>
              <td>{inquiry.externalUserId}</td>
              <td>{inquiry.email || '-'}</td>
              <td><span className="pill">{inquiry.status}</span></td>
              <td>{inquiry.providerMode}</td>
              <td>{inquiry.providerInquiryId}</td>
            </tr>
          ))}
          {inquiries.length === 0 && (
            <tr>
              <td colSpan={5} className="empty">No inquiries yet.</td>
            </tr>
          )}
        </tbody>
      </table>
    </main>
  );
}
