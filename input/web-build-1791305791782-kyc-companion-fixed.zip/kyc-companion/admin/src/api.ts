export type Inquiry = {
  id: string;
  externalUserId: string;
  email: string;
  status: string;
  provider: string;
  providerMode: string;
  providerInquiryId: string;
  createdAt: string;
  updatedAt: string;
};

const baseUrl = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080';

export async function listInquiries(): Promise<Inquiry[]> {
  const response = await fetch(`${baseUrl}/api/inquiries`);
  if (!response.ok) {
    throw new Error(`Could not load inquiries: ${response.status}`);
  }
  return response.json();
}

export async function createInquiry(input: { externalUserId: string; email: string }): Promise<Inquiry> {
  const response = await fetch(`${baseUrl}/api/inquiries`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
  if (!response.ok) {
    throw new Error(`Could not create inquiry: ${response.status}`);
  }
  return response.json();
}
