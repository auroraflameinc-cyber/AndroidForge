plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.kyccompanion"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.kyccompanion"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
}

dependencies {
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3:1.3.1")
    implementation("androidx.compose.ui:ui:1.7.5")
    implementation("androidx.compose.ui:ui-tooling-preview:1.7.5")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")

    // Add the official Persona Android SDK dependency from Persona's current docs.
    // Keep this boundary isolated in PersonaLauncher so mock mode remains runnable.
    // implementation("com.withpersona.sdk2:inquiry:<persona-version>")

    testImplementation("junit:junit:4.13.2")
}
