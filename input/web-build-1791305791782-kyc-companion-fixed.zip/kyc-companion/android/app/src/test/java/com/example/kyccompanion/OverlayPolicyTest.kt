package com.example.kyccompanion

import org.junit.Assert.assertFalse
import org.junit.Test

class OverlayPolicyTest {
    @Test
    fun overlayPolicyDoesNotClaimBypassBehavior() {
        val supportedCapabilities = listOf("visible-status", "user-dismissable", "permission-gated")
        assertFalse(supportedCapabilities.contains("hidden-overlay"))
        assertFalse(supportedCapabilities.contains("camera-injection"))
        assertFalse(supportedCapabilities.contains("sensor-spoofing"))
    }
}
