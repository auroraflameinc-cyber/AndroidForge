package com.example.kyccompanion.persona

import android.app.Activity
import android.widget.Toast

interface PersonaLauncher {
    fun startInquiry(activity: Activity, clientToken: String)
}

class MockPersonaLauncher : PersonaLauncher {
    override fun startInquiry(activity: Activity, clientToken: String) {
        Toast.makeText(activity, "Mock Persona inquiry: $clientToken", Toast.LENGTH_LONG).show()
    }
}

class ProductionPersonaLauncher : PersonaLauncher {
    override fun startInquiry(activity: Activity, clientToken: String) {
        /*
         * Wire the official Persona Android SDK here using Persona's current docs.
         * Keep production credentials on the backend. The Android app should receive
         * only a short-lived inquiry/session token from your API.
         */
        Toast.makeText(activity, "Persona SDK integration point", Toast.LENGTH_LONG).show()
    }
}
