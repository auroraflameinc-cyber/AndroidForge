package com.example.kyccompanion.model

enum class VerificationStatus(val label: String) {
    Ready("Ready"),
    Created("Inquiry created"),
    InProgress("Verification in progress"),
    Completed("Verification completed"),
    Failed("Verification failed"),
}
