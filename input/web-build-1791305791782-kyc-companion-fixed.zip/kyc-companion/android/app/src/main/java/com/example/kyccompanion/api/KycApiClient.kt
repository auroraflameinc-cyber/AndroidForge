package com.example.kyccompanion.api

import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

data class InquiryResponse(
    val id: String,
    val providerInquiryId: String,
    val clientToken: String,
    val status: String,
)

class KycApiClient(private val baseUrl: String) {
    fun createInquiry(externalUserId: String, email: String): InquiryResponse {
        val url = URL("$baseUrl/api/inquiries")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json")
            connectTimeout = 10_000
            readTimeout = 10_000
            doOutput = true
        }

        val body = JSONObject()
            .put("externalUserId", externalUserId)
            .put("email", email)
            .toString()

        OutputStreamWriter(connection.outputStream).use { it.write(body) }
        val stream = if (connection.responseCode in 200..299) {
            connection.inputStream
        } else {
            connection.errorStream
        }
        val response = stream.bufferedReader().use { it.readText() }
        if (connection.responseCode !in 200..299) {
            error("API error ${connection.responseCode}: $response")
        }

        val json = JSONObject(response)
        return InquiryResponse(
            id = json.getString("id"),
            providerInquiryId = json.getString("providerInquiryId"),
            clientToken = json.optString("clientToken"),
            status = json.getString("status"),
        )
    }
}
