package com.example.kyccompanion

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.kyccompanion.model.VerificationStatus
import com.example.kyccompanion.overlay.VerificationOverlayService
import com.example.kyccompanion.persona.MockPersonaLauncher

class MainActivity : ComponentActivity() {
    private val personaLauncher = MockPersonaLauncher()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KycCompanionApp(
                canDrawOverlays = Settings.canDrawOverlays(this),
                onRequestOverlayPermission = { requestOverlayPermission() },
                onStartOverlay = { startService(Intent(this, VerificationOverlayService::class.java)) },
                onStopOverlay = { stopService(Intent(this, VerificationOverlayService::class.java)) },
                onStartKyc = { personaLauncher.startInquiry(this, "mock_client_token_demo") },
            )
        }
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName"),
        )
        startActivity(intent)
    }
}

@Composable
fun KycCompanionApp(
    canDrawOverlays: Boolean,
    onRequestOverlayPermission: () -> Unit,
    onStartOverlay: () -> Unit,
    onStopOverlay: () -> Unit,
    onStartKyc: () -> Unit,
) {
    val status = remember { mutableStateOf(VerificationStatus.Ready.label) }

    MaterialTheme {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("KYC Companion", style = MaterialTheme.typography.headlineMedium)
            Text(status.value)
            Button(onClick = {
                status.value = VerificationStatus.InProgress.label
                onStartKyc()
            }) {
                Text("Start KYC")
            }
            Button(onClick = onRequestOverlayPermission) {
                Text(if (canDrawOverlays) "Overlay Permission Granted" else "Grant Overlay Permission")
            }
            Button(onClick = onStartOverlay, enabled = canDrawOverlays) {
                Text("Show Status Overlay")
            }
            Button(onClick = onStopOverlay) {
                Text("Hide Status Overlay")
            }
        }
    }
}
